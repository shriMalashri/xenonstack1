package com.pgmates.dtos;

public class SearchDTO {

	private String gender;
	private String furnish;
	private String atype;
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getFurnish() {
		return furnish;
	}
	public void setFurnish(String furnish) {
		this.furnish = furnish;
	}
	public String getAtype() {
		return atype;
	}
	public void setAtype(String atype) {
		this.atype = atype;
	}
	
	
	
}
