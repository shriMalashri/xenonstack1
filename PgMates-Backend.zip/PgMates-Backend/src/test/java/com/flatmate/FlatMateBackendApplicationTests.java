package com.flatmate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlatMateBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
